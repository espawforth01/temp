#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void process_input(char *input) {
    char buffer[128];
    int secret = 123456;
    printf("Processing input...\n");
    strcpy(buffer, input);
    printf("%d\n", secret);
}
void menu() {
    char choice[16];
    printf("Menu:\n");
    printf("1. Enter data\n");
    printf("2. Exit\n");
    printf("Choice: ");
    gets(choice);
    if (strcmp(choice, "1") == 0) {
        char user_input[512];
        printf("Enter your text: ");
        fgets(user_input, sizeof(user_input), stdin);
        process_input(user_input);
    } else {
        printf("Exiting...\n");
        exit(0);
    }
}
int main() {
    menu();
    return 0;
}
