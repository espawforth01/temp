#include <windows.h>
int main() {
WinExec("cmd.exe", SW_SHOW);
return 0;
}